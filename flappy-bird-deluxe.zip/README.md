# Flappy Bird Deluxe

Game HTML5 satu file, tanpa library eksternal.

Fitur:
- Karakter burung animasi
- Suara via Web Audio API
- Start screen
- High score tersimpan di localStorage
- Background bergerak
- Koin dan total koin tersimpan
- Responsive untuk HP/desktop
- Bisa dimainkan dengan tap, klik, Spasi, atau Arrow Up

## Deploy
### GitHub Pages
Upload `index.html` ke repository → Settings → Pages → Deploy from branch → `main` → `/root`.

### Netlify
Upload `index.html` atau folder proyek melalui opsi deploy manual.

Tidak membutuhkan database, backend, atau asset eksternal.
